# Yash Rathod — Personal Portfolio

A personal portfolio website built with HTML and CSS to showcase skills, education, projects, and contact details.

## Repository Structure

```text
├── index.html   # Main HTML markup
├── style.css    # Stylesheet and responsive layout
└── README.md    # Repository documentation
```

## Setup & Deployment

1. Extract or clone the repository.
2. Open `index.html` in a browser to preview locally, or enable **GitHub Pages** from repository settings to publish online.
