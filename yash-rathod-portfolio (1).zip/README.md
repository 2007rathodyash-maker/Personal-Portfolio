# Yash Rathod — Personal Portfolio

A clean, colorful, responsive personal portfolio website built with HTML5 and CSS3 to showcase skills, projects, and contact details.

## Repository Structure

```text
├── index.html   # Main HTML structure
├── style.css    # Styling, layout, and responsive rules
└── README.md    # Project documentation
```

## Getting Started

1. Clone or download this repository.
2. Open `index.html` directly in any web browser, or deploy via **GitHub Pages** (`Settings` → `Pages` → select `main` branch).
